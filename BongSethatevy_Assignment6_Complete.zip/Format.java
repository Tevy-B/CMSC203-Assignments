/**
 * Enumeration class for movie ratings
 * @author Sethatevy Bibg
 */
public enum Format {
    IMAX, THREE_D, NONE
}