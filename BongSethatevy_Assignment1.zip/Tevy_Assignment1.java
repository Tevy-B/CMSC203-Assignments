import java.util.Scanner;

public class Tevy_Assignment1 {

	public static void main(String[] args)
	{
		double TempInFa;
		double WindSpeed;
		double WindChillInFa;
		final double NUM1 = 35.74, NUM2 = 0.6215, NUM3= -35.75, NUM4 = 0.4275;
		
		System.out.println("Wind Chill Calculator\n");
		//create a scanner object for keyboard input
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter the temperature in Fahrenheit (must be >= -45 and <= 40):");
		TempInFa = keyboard.nextDouble();
		
		
		//Determine whether the user input between -45 and 40 inclusively
		if (TempInFa >=- 45 && TempInFa <= 40)
		{
			System.out.print("Enter the wind speed (must be >= 5 and <= 60): ");
			WindSpeed = keyboard.nextDouble();
			if( WindSpeed < 5 || WindSpeed > 60) 
			{
				System.out.println("The wind speed is not between 5 and 60 inclusively!");
			}
				else 
				{
					WindChillInFa = NUM1 + (NUM2*TempInFa) + (NUM3*(Math.pow(WindSpeed,0.16))) + (NUM4*TempInFa*(Math.pow(WindSpeed,0.16)));
					System.out.println("\nWind chill temperature: " + WindChillInFa + " degrees Fahrenheit.");
				}
		}
			else 
			{
				System.out.println("The temperature is not between -45 and 40 inclusively!");
			}


		System.out.print("\nProgrammer: Sethatevy Bong");
		
	}
}
