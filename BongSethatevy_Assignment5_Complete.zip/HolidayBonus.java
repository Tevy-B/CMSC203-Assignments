

public class HolidayBonus {

	/**
	 * Calculates the holiday bonus for each store
	 * @param data the two dimensional array of store sales
	 * @param high bonus for the highest store in a category
	 * @param low bonus for the lowest store in a category
	 * @param other bonus for all other stores in a category
	 * @return an array of the bonus for each store
	 */
	public static double[] calculateHolidayBonus(double[][] data, double high, double low, double other){
		int numStores = data.length;
		int numCategories = 0;
		double[] bonus = new double[numStores];
		//find holiday bonus for each row
		for(int store = 0; store<numStores; store++){
			bonus[store] = 0;
			numCategories = data[store].length;
			System.out.println("row "+store+" columns "+numCategories);
			for (int category=0;category<numCategories;category++){
				//look at the highest for each column and see if it matches the row
				if(TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, category)==store){
					if(data[store][category]>0)
						bonus[store] += high;
				}
				//look at the smallest for each column and see if it matches the row
				else if(TwoDimRaggedArrayUtility.getLowestInColumnIndex(data, category)==store){
					if(data[store][category]>0)
						bonus[store]+= low;
				}
				//if not lowest or highest, received "other" bonus
				else
					if(data[store][category]>0)
						bonus[store] += other;
			}
		}
		return bonus;
	}
	
	/**
	 Calculates the total holiday bonuses
	 * @param data the two dimensional array of store sales
	 * @param high bonus for the highest store in a category
	 * @param low bonus for the lowest store in a category
	 * @param other bonus for all other stores in a category
	 * @return the total of all holiday bonuses
	 */
	public static double calculateTotalHolidayBonus(double[][] data, double high, double low, double other){
		double result=0;
		double[] bonuses = HolidayBonus.calculateHolidayBonus(data, high, low, other);
		for(int i=0;i<bonuses.length;i++)
			result += bonuses[i];
		return result;
		
	}
}

