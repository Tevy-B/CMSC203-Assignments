/*
 * @author Sethatevy
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TwoDimRaggedArrayUtility {

	public TwoDimRaggedArrayUtility() 
	{
		//empty constructor
	}
/**
 * Reads from a file and returns a ragged array of doubles The maximum rows is 10 and the maximum columns for each row is 10 Each row in the file 
 * is separated by a new line Each element in the row is separated by a space Suggestion: You need to know how many rows and how many columns 
 * there are for each row to create a ragged array. 1. Read the doubles from the file into an a temporary array [10][10] 
 * of Strings which was initialized to nulls. 2. Find out how many rows there are (any row that has the first element != null is a valid row) 
 * 3. Create the array based on the num of rows, i.e. double[][]array = new double[#rows][] 4. Determine the number of columns for the 
 * first row (any element != null is a valid element) 5. Create the first row, i.e. array[0] = new double[#columns] 
 * 6. Put the values from the temporary array into in the row (don't forget to convert from strings to doubles) 7. Repeat for all rows
 * @param file
 * @return sales
 * @throws FileNotFoundException
 */
	public static double[][] readFile(File file) throws FileNotFoundException {
		//make an assumption which are larger than what we need - row and column
		String[][] input = new String[10][10];
		Scanner sc = new Scanner(file);
		int row = 0, col = 0;

		while (sc.hasNextLine()) {
			String[] currentRow = sc.nextLine().split(" ");
			for (col = 0; col < currentRow.length; col++) {
				input[row][col] = currentRow[col];
			}
			row++;
		}

		sc.close();

		double[][] sales = new double[row][];
		// if the box is not empty move to the next column
		for (row = 0; row < sales.length; row++) {
			for (col = 0; input[row][col] != null; col++) {	}			
			sales[row] = new double[col];
			for (col = 0; col < sales[row].length; col++) {
				//turn string to double
				sales[row][col] = Double.parseDouble(input[row][col]);
			}
		}
		return sales;
	}
	
	/**
	 * Writes the ragged array of doubles into the file. Each row is on a separate line within the file and each double is separated by a space.
	 * @throws FileNotFoundException
	 * @param outputFile
	 * @param [][]data
	 */
	public static void writeToFile(double[][] data, File outputFile) {//throws FileNotFoundException {
	try {
	
		PrintWriter file = new PrintWriter(outputFile);
		for (int row = 0; row < data.length; row++) {
			for (int col = 0; col < data[row].length; col++) {
				file.print((col != 0) ? " " + data[row][col] : data[row][col]);
			}
			file.println();
		}
		file.close();
		}
		catch(FileNotFoundException e)
		{
		e.getMessage();
		}
	}
/**
 * Returns the total of all the elements of the two dimensional array
 * @param [][]data
 * @return total
 */
	public static double getTotal(double[][] data) {
		double total = 0;
		for (int row = 0; row < data.length; row++) {
			for (int column = 0; column < data[row].length; column++) {
				total += data[row][column];
			}
		}
		return total;
	}
/**
 * Returns the average of the elements in the two dimensional array
 * @param data
 * @return total/count -- average
 */
	public static double getAverage(double[][] data) {
		int count = 0;
		double total = 0;
		for (int row = 0; row < data.length; row++) {
			for (int column = 0; column < data[row].length; column++) {
				total += data[row][column];
				count++;
			}
		}
		return total/count;
	}

/**
 * Returns the total of the selected row in the
 * two dimensional array index 0 refers to the first row.
 * @param data
 * @return rowTotal
 */
	public static double getRowTotal(double[][] data, int row) {

		double rowTotal = 0;
		for (int col = 0; col < data[row].length; col++) {
			rowTotal += data[row][col];
		}
		return rowTotal;
	}
/**
 * Returns the total of the selected column in the two dimensional array index 0 refers to the first column. 
 * If a row in the two dimensional array doesn't have this column index, 
 * it is not an error, it doesn't participate in this method.
 * @param data
 * @param col
 * @return
 */
	public static double getColumnTotal(double[][] data, int col) {

		double colTotal = 0;
		for (int row = 0; row < data.length; row++) {
			if (col < data[row].length) {
				colTotal += data[row][col];
			}
		}
		return colTotal;
	}
/**
 * Returns the largest element of the selected row in the two dimensional array index 0 refers to the first row.
 * @param data
 * @param row
 * @return highest
 */
	public static double getHighestInRow(double[][] data, int row) {

		double highest = data[0][0];
		int colCheck = 0;
		
		while (colCheck < data.length) {
			if (colCheck < data[row].length) {
				highest = data[row][colCheck];
				break;
			} else {
				colCheck++;
			}
		}

		for (int col = 0; col < data[row].length; col++) {
			if (data[row][col] > highest) {
				highest = data[row][col];
			}
		}
		return highest;
	}
/**
 * Returns the largest element of the selected row in the two dimensional array 
 * index 0 refers to the first row.
 * @param data
 * @param row
 * @return highest
 */
	public static int getHighestInRowIndex(double[][] data, int row) {

		double highestElement = data[0][0];
		int highest = 0;
		int colCheck = 0;
		
		while (colCheck < data.length) {
			if (colCheck < data[row].length) {
				highestElement = data[row][colCheck];
				break;
			} else {
				colCheck++;
			}
		}
		
		for (int col = 0; col < data[row].length; col++) {
			if (data[row][col] > highestElement) {
				highestElement = data[row][col];
				highest = col;
			}
		}
		return highest;
	}
/**
 * Returns the smallest element of the selected row in the two dimensional array index 0 refers to the first row.
 * @param data
 * @param row
 * @return lowest
 */
	public static double getLowestInRow(double[][] data, int row) {

		double lowest = data[0][0];
		int colCheck = 0;
		
		while (colCheck < data.length) {

			if (colCheck < data[row].length) {
				lowest = data[row][colCheck];
				break;
			} else {
				colCheck++;
			}
		}
		for (int col = 0; col < data[row].length; col++) {
			if (data[row][col] < lowest) {
				lowest = data[row][col];
			}
		}
		return lowest;
	}
/**
 * Returns the index of the smallest element of the selected row in the two dimensional array index 0 refers to the first row.
 * @param data
 * @param row
 * @return lowest
 */
	public static int getLowestInRowIndex(double[][] data, int row) {
		
		double lowestElement = data[0][0];
		int lowest = 0;
		int colCheck = 0;

		while (colCheck < data.length) {
			if (colCheck < data[row].length) {
				lowestElement = data[row][colCheck];
				break;
			} else {
				colCheck++;
			}
		}

		for (int col = 0; col < data[row].length; col++) {
			if (data[row][col] < lowestElement) {
				lowestElement = data[row][col];
				lowest = col;
			}
		}
		return lowest;
	}
/**
 * Returns the largest element of the selected column in the two dimensional array index 0 refers to the first column. 
 * If a row in the two dimensional array doesn't have this column index, it is not an error, it doesn't participate in this method.
 * @param data
 * @param col
 * @return highest
 */
	public static double getHighestInColumn(double[][] data, int col) {

		double highest = data[0][0];
		int rowCheck = 0;
		while (rowCheck < data.length) {
			if (col < data[rowCheck].length) {
				highest = data[rowCheck][col];
				break;
			} else {
				rowCheck++;
			}
		}

		for (int row = 0; row < data.length; row++) {
			if (col < data[row].length)  {
				if (data[row][col] > highest) {
					highest = data[row][col];
				}
			}
		}
		return highest;
	}
/**
 * Returns index of the largest element of the selected column in the two dimensional array index 0 refers to the first column. 
 * If a row in the two dimensional array doesn't have this column index, it is not an error, 
 * it doesn't participate in this method.
 * @param data
 * @param col
 * @return highest
 */
	public static int getHighestInColumnIndex(double[][] data, int col) {
		double highestElement = data[0][0];
		int highest = 0;
		int rowCheck = 0;

		while (rowCheck < data.length) {
			if (col < data[rowCheck].length) {
				highestElement = data[rowCheck][col];
				break;
			} 
			else {
				rowCheck++;
			}
		}

		for (int row = 0; row < data.length; row++) {
			if (col < data[row].length) {
				if (data[row][col] > highestElement) {
					highestElement = data[row][col];
					highest = row;
				}
			}
		}

		return highest;
	}
	/**
	 * Returns the smallest element of the selected column in the two dimensional array index 0 refers to the first column. 
	 * If a row in the two dimensional array doesn't have this column index, 
	 * it is not an error, it doesn't participate in this method.
	 * @param data
	 * @param col
	 * @return lowest
	 */
	public static double getLowestInColumn(double[][] data, int col) {

		double lowest = data[0][0];
		int rowCheck = 0;
		while (rowCheck < data.length) {
			if (col < data[rowCheck].length) {
				lowest = data[rowCheck][col];
				break;
			} 
			else {
				rowCheck++;
			}
		}
		for (int row = 0; row < data.length; row++) {
			if (col < data[row].length) {
				if (data[row][col] < lowest) {
					lowest = data[row][col];
				}
			}
		}

		return lowest;

	}

	/**
	 * Returns the index of the smallest element of the selected column in the two dimensional array index 0 refers to the first column. 
	 * If a row in the two dimensional array doesn't have this column index, it is not an error, it doesn't participate in this method.
	 * @param data
	 * @param col
	 * @return lowest
	 */
	public static int getLowestInColumnIndex(double[][] data, int col) {
		
		double lowestElement = data[0][0];
		int lowest = 0;
		int rowCheck = 0;

		while (rowCheck < data.length) {
			if (col < data[rowCheck].length) {
				lowestElement = data[rowCheck][col];
				break;
			} 
			else {
				rowCheck++;
			}
		}

		for (int row = 0; row < data.length; row++) {
			if (col < data[row].length) {
				if (data[row][col] < lowestElement) {
					lowestElement = data[row][col];
					lowest = row;
				}
			}
		}

		return lowest;

	}
/**
 * Returns the largest element in the two dimensional array
 * @param [][]data
 * @return highest
 */
	public static double getHighestInArray(double[][] data) {

		double highest = data[0][0];
		for (int row = 0; row < data.length; row++) {
			for (int col = 0; col < data[row].length; col++) {
				if (data[row][col] > highest) {
					highest = data[row][col];
				}			
			}
		}
		return highest;
	}
/**
 * Returns the smallest element in the two dimensional array
 * @param [][]data
 * @return lowest
 * 
 */
	public static double getLowestInArray(double[][] data) {

		double lowest = data[0][0];
		for (int row = 0; row < data.length; row++) {
			for (int col = 0; col < data[row].length; col++) {
				if (data[row][col] < lowest) {
					lowest = data[row][col];
				}			
			}
		}
		return lowest;
	}
}
