/**
 * 
 * @author Sethatevy
 *
 */
public class ManagementCompany {

    private final int MAX_PROPERTY = 5, MGMT_WIDTH = 10, MGMT_DEPTH = 10;
    private double mgmFeePer;
    private String name, taxID;
    private Plot plot;
    private Property[] properties;

/**
 * No-Arg Constructor that creates a ManagementCompany object using empty strings and the plot set to a Plot with x, y
 *  set to 0 , width and depth set to 10. properties array is initialized here as well.
 */
    public ManagementCompany()
    {
        this.name = "";
        this.taxID = "";
        this.mgmFeePer = 0;
        this.plot = new Plot(0, 0, 10, 10);
        this.properties = new Property[MAX_PROPERTY];
    }

    /**
     * Constructor Creates a ManagementCompany object using the passed information. 
     * plot is set to a Plot with x, y set to 0 , width and depth set to 10
     * properties array is initialized here as well
     * @param name
     * @param taxID
     * @param mgmFeePer
     */
    public ManagementCompany(String name, String taxID, double mgmFeePer){
        this.name = name;
        this.taxID = taxID;
        this.mgmFeePer = mgmFeePer;
        this.plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
        this.properties = new Property[MAX_PROPERTY];
    }
    
    /**
     * Constructor Creates a ManagementCompany object using the passed information.
     * @param name
     * @param taxID
     * @param mgmFeePer
     * @param x
     * @param y
     * @param width
     * @param depth
     */
    public ManagementCompany(String name, String taxID, double mgmFeePer, int x, int y, int width, int depth){
        this.name = name;
        this.taxID = taxID;
        this.mgmFeePer = mgmFeePer;
        this.plot = new Plot(x, y, width, depth);
        this.properties = new Property[MAX_PROPERTY];
    }
    
    /**
     * Copy Constructor that creates a ManagementCompany object from another ManagementCompany object
     * @param otherCompany
     */
    public ManagementCompany(ManagementCompany otherCompany){
        this.name = otherCompany.name;
        this.taxID = otherCompany.taxID;
        this.mgmFeePer = otherCompany.mgmFeePer;
        this.plot = new Plot(otherCompany.plot);
        this.properties = new Property[MAX_PROPERTY];
    }

    public int getMAX_PROPERTY(){
        return  MAX_PROPERTY;
    }


    /**
     * Adds the property object to the "properties" array.
     * Returns either -1 if the array is full, -2 if property is null, -3 if the plot is not contained by the MgmtCo plot,
     * -4 of the plot overlaps any other property, or the index in the array where the property was added successfully.
     * @param property
     * @return
     */
    public int addProperty(Property property)
    {
        if (property == null){
            return -2;
        }

        else if (!plot.encompasses(property.getPlot())){
            return -3;
        }

        for (int counter = 0; counter < properties.length; counter++){
            if (properties[counter] != null){
                if (properties[counter].getPlot().overlaps(property.getPlot())){
                    return -4;
                }
            }
            else{
                properties[counter] = property;
                return counter;
            }
        }

        return -1;
    }
    
    /**
     * Creates a property object and adds it to the "properties" array, in a default plot.
     * Returns either -1 if the array is full, -2 if property is null, -3 if the plot is not contained by the MgmtCo plot, 
     * -4 of the plot overlaps any other property, or the index in the array where the property was added successfully.
     * @param name
     * @param city
     * @param rent
     * @param owner
     * @return
     */
    public int addProperty(String name, String city, double rent, String owner)
    {
        return addProperty(new Property(name, city, rent, owner));
    }
    
    /**
     * Creates a property object and adds it to the "properties" array.
     * Returns either -1 if the array is full, -2 if property is null, -3 if the plot is not contained by the MgmtCo plot, 
     * -4 of the plot overlaps any other property, or the index in the array where the property was added successfully.
     * @param name
     * @param city
     * @param rent
     * @param owner
     * @param x
     * @param y
     * @param width
     * @param depth
     * @return
     */
    public int addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth)
    {
        return addProperty(new Property(name, city, rent, owner, x, y, width, depth));
    }

    /**
     * This method accesses each "Property" object within the array "properties" 
     * and sums up the property rent and returns the total amount.
     * @return rentTotal
     */
    public double totalRent()
    {
        double rentTotal = 0;
        for(Property prop : properties)
        {
            if (prop == null){
                break;
            }
            rentTotal += prop.getRentAmount();
        }
        return rentTotal;
    }
//need more practice
    /**
     * This method finds the property with the maximum rent amount and returns its toString result. 
     * NOTE: For simplicity assume that each "Property" object's rent amount is different.
     * @return maxRentAmount
     */
    public double maxRentProp()
    {
        double maxRentAmount = 0;
        for (Property prop : properties){
            if (prop == null){
                break;
            }
            if (maxRentAmount < prop.getRentAmount()){
                maxRentAmount = prop.getRentAmount();
            }
        }
        return maxRentAmount;
    }
//test2
    /**
     * This method finds the index of the property with the maximum rent amount. 
     * NOTE: For simplicity assume that each "Property" object's rent amount is different.
     * @return maxIndex
     */
    public int maxRentPropertyIndex()
    {
        int maxIndex = -1;
        double maxRentAmount = 0;

        for (int counter = 0; counter < properties.length; counter++){
            if (properties[counter] == null){
                break;
            }
            if( maxRentAmount < properties[counter].getRentAmount()){
                maxRentAmount = properties[counter].getRentAmount();
                maxIndex = counter;
            }
        }
        return  maxIndex;
    }
    
    /**
     * Displays the information of the property at index i
     * @param i
     * @return toReturn
     */
    public String displayPropertyAtIndex(int i)
    {
        String toReturn;
        toReturn = properties[i].toString();
        return toReturn;
    }
    
    /**
     * return information of ALL the properties within this management company by accessing the "Properties" array.
     */
    public String toString()
    {
        String toReturn = "";
        toReturn += "List of the properties for " + name + ", taxID: " + taxID + "\n";
        toReturn += "__________________________________________________________________________\n";
        for (Property prop : properties){
            if (prop == null){
                break;
            }
            toReturn += prop.toString();
            toReturn += "\n";
        }
        toReturn += "__________________________________________________________________________\n";
        toReturn += "total management Fee: " + (totalRent() * mgmFeePer / 100);
        return  toReturn;
    }
}