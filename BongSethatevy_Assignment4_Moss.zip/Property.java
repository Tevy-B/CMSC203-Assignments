public class Property {

    private String city, owner, propertyName;
    private double rentAmount;
    private Plot plot;

    /**
     * No-arg Constructor, creates a new object with default values of empty strings, 
     * 0 for rent amount, and default Plot (sets the x, y values to zero, depth and width to 1)
     */
    public Property()
    {
        this.city = "";
        this.owner = "";
        this.propertyName = "";
        this.rentAmount = 0.0;
        this.plot = new Plot();
    }

    /**
     * Copy Constructor, creates a new object using the information of the object passed to it.
     * @param propertyName
     * @param city
     * @param rentAmount
     * @param owner
     */
    public Property(String propertyName, String city, double rentAmount, String owner)
    {
        this.propertyName = propertyName;
        this.city = city;
        this.rentAmount = rentAmount;
        this.owner = owner;
        this.plot = new Plot();
    }

    /**
     * Parameterized Constructor, no Plot information provided
     * @param propertyName
     * @param city
     * @param rentAmount
     * @param owner
     * @param x
     * @param y
     * @param width
     * @param depth
     */
    public Property(String propertyName, String city, double rentAmount, String owner, int x, int y, int width, int depth)
    {
        this.propertyName = propertyName;
        this.city = city;
        this.rentAmount = rentAmount;
        this.owner = owner;
        this.plot = new Plot(x, y, width, depth);
    }

    /**
     * Constructor, Parameterized constructor
     * @param p
     */
    public Property(Property p)
    {
        this.city = p.city;
        this.owner = p.owner;
        this.rentAmount = p.rentAmount;
        this.propertyName = p.propertyName;
        this.plot = new Plot(p.plot);
    }

    public String getCity()
    {
        return city;
    }

    public String getOwner()
    {
        return owner;
    }

    public String getPropertyName()
    {
        return propertyName;
    }

    public double getRentAmount()
    {
        return rentAmount;
    }

    //html file of this class online miss this method 
    public Plot getPlot()
    {
        return plot;
    }

    public Plot setPlot(int x, int y, int width, int depth)
    {
        return new Plot(x, y, width, depth);
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public void setOwner(String owner)
    {
        this.owner = owner;
    }

    public void setPropertyName(String propertyName)
    {
        this.propertyName = propertyName;
    }

    public void setRentAmount(double rentAmount)
    {
        this.rentAmount = rentAmount;
    }

    /**
     * Prints out the name, city, owner and rent amount for a property
     * Overrides: toString in class java.lang.Object
     */
    public String toString()
    {
        String toReturn = "Property Name: " + propertyName + "\nLocation: " + city + "\nBelonging to: " + owner +
                "\nRent Amount: " + rentAmount;
        return toReturn;
    }
}
