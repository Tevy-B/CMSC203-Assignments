public class Plot {

    private int x, y, width, depth;
    
    /**
     * No-arg Constructor, creates a default Plot with args x=0, y=0, width=1, depth=1
     */
    public Plot()
    {
        x = 0;
        y = 0;
        width = 1;
        depth = 1;
    }
    
    /**
     * Copy Constructor, creates a new object using the information of the object passed to it.
     * @param x
     * @param y
     * @param width
     * @param depth
     */
    public Plot(int x, int y, int width, int depth)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.depth = depth;
    }
    
    /**
     * Parameterized Constructor
     * @param p
     */
    public Plot (Plot p)
    {
        this.x = p.x;
        this.y = p.y;
        this.width = p.width;
        this.depth = p.depth;
    }

    	/**
    	 * Determines if this plot overlaps the parameter
    	 * @param p
    	 * @return  true if this plot overlaps the parameter, false otherwise
    	 */
    public boolean overlaps(Plot p)
    {
        boolean oneOverlapsXYone, oneOverlapsXYtwo, twoOverlapsXYone, twoOverlapsXYtwo,threeOverlapsXYone
        , threeOverlapsXYTwo, fourOverlapsXYone, fourOverlapsXYtwo;

        oneOverlapsXYone = (p.x >= x && p.x < (x+width)) && (p.y >= y && p.y < (y+depth));
        oneOverlapsXYtwo = (x >= p.x && x < (p.x + width)) && (y >= p.y && y < (p.depth + p.y));

        twoOverlapsXYone =  (p.x + p.width) > x && (p.x + p.width) < (x + width) &&  p.y >= y && p.y <= (y + depth);
        twoOverlapsXYtwo = (x + width) > p.x && (x + width) < (p.x + p.width) && y>= p.y && y <= (p.y + p.depth);

        threeOverlapsXYone = p.x >= x && p.x < (x + width) && (p.y + p.depth) > y && (p.y + p.depth) <= (y + depth);
        threeOverlapsXYTwo =  x >= p.x && x < (p.x +  p.width) && (y + depth) > p.y && (y + depth) <= (p.y + p.depth);

        fourOverlapsXYone = (p.x + p.width) > x && (p.x +p.width) <= (x + width) && (p.y + p.depth) > y && (p.y + p.depth) <= (y + depth);
        fourOverlapsXYtwo = (x + width) > p.x && (x + width) <= (p.x + p.width) && (y + depth) > p.y && (y + depth) <= (p.y + p.depth);

        return oneOverlapsXYone || oneOverlapsXYtwo || twoOverlapsXYone || twoOverlapsXYtwo || threeOverlapsXYone
                || threeOverlapsXYTwo || fourOverlapsXYone || fourOverlapsXYtwo;
    }

    /**
     * Determines if this plot encompasses the parameter
     * @param p
     * @return Returns true if this plot encompasses the parameter, false otherwise
     */
    public boolean encompasses(Plot p)
    {
        boolean inX, inY, inWidth, inDepth;
        inX = p.x >= x;
        inY = p.y >= y;
        inWidth = (p.x + p.width) <= (x + width);
        inDepth = (p.y + p.depth) <= (y + depth);
        return inX && inY && inWidth && inDepth;
    }

    public void setX(int x)
    {
        this.x = x;
    }

    public int getX()
    {
        return x;
    }

    public void setY(int y)
    {
        this.y = y;
    }

    public int getY()
    {
        return y;
    }

    public void setWidth(int width)
    {
        this.width = width;
    }
    public int getWidth()
    {
        return width;
    }

    public void setDepth(int depth)
    {
        this.depth = depth;
    }
    public int getDepth()
    {
        return depth;
    }

    public String toString()
    {
        String toReturn = "Upper Left: (" + x + "," + y + ")" +
                "  Width: " + width + " Depth: " + depth;
        return toReturn;
    }
}
